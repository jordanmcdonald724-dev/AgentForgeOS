"""Assets module backend routes."""
