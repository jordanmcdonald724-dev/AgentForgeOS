"""Builds module backend routes."""
