"""Studio module backend routes."""
